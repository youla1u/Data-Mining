Ce programme permet de savoir si un item graduel est fréquent ou non 
en fonction d'un minsup.

Por l'exécuter:

1) Charger un ficher au format "txt" contenant les données.


2) Indique le numéro de colonne correspondant à un item graduel choisi. 

3) Indiquer le minsup


Remarques: 1) Dans se programme on n'évalu que les items graduels.Les itemsets de taille 
              supérieur ou égales à 2 n'y sont pas testés pour l'instant.
           
           2) Le sens de croissance n'est pas à indiquer dans ce programme car le support
              d'un item graduel est égale au support de son complémentaire.       